create function set_contract_number_default() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.contract_number IS NULL THEN
        NEW.contract_number := nextval('contract_number_sequence');
    END IF;
    RETURN NEW;
END;
$$;

alter function set_contract_number_default() owner to postgres;

